# Simple-Calculator-Android-Studio-Project
This is done for university assignment.
